<?php
/**
 * Plugin Name: LearnDash Buy Now Button
 * Plugin URI: https://yourwebsite.com/plugins/learndash-buy-now-button
 * Description: Adds a customizable Buy Now button for LearnDash courses with instant checkout options.
 * Version: 1.0.0
 * Author: Your Name
 * Author URI: https://yourwebsite.com
 * Text Domain: learndash-buy-now
 * Domain Path: /languages
 * Requires at least: 5.0
 * Requires PHP: 7.2
 * WC requires at least: 4.0
 * WC tested up to: 8.0
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('LDBNB_VERSION', '1.0.0');
define('LDBNB_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('LDBNB_PLUGIN_URL', plugin_dir_url(__FILE__));

/**
 * Main Plugin Class
 */
class LearnDash_Buy_Now_Button {

    /**
     * Constructor
     */
    public function __construct() {
        // Register shortcode
        add_shortcode('learndash_buy_button', array($this, 'learndash_buy_button_shortcode'));

        // Register AJAX handlers
        add_action('wp_ajax_instant_buy_now', array($this, 'process_instant_buy_now'));
        add_action('wp_ajax_nopriv_instant_buy_now', array($this, 'process_instant_buy_now'));

        // Enqueue scripts and styles
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));

        // Add checkout URL to script
        add_action('wp_footer', array($this, 'add_checkout_url_to_script'));
    }

    /**
     * Enqueue scripts and styles
     */
    public function enqueue_scripts() {
        wp_enqueue_style(
            'ldbnb-styles',
            LDBNB_PLUGIN_URL . 'assets/css/styles.css',
            array(),
            LDBNB_VERSION
        );

        wp_enqueue_script(
            'ldbnb-scripts',
            LDBNB_PLUGIN_URL . 'assets/js/scripts.js',
            array('jquery'),
            LDBNB_VERSION,
            true
        );
    }

    /**
     * Add checkout URL to script
     */
    public function add_checkout_url_to_script() {
        if (function_exists('wc_get_checkout_url')) {
            ?>
            <script type="text/javascript">
                var wc_checkout_url = '<?php echo wc_get_checkout_url(); ?>';
                var ajaxurl = '<?php echo admin_url("admin-ajax.php"); ?>';
            </script>
            <?php
        }
    }

    /**
     * LearnDash Buy Button Shortcode
     */
    public function learndash_buy_button_shortcode($atts) {
        // Get shortcode attributes
        $atts = shortcode_atts(array(
            'course_id' => get_the_ID(), // Default to current course
            'button_text' => 'Buy Now',
            'show_price' => 'yes',
            'class' => '',
            'style' => 'default' // default, plain, or minimal
        ), $atts);

        // If not a course, return empty
        if (!$atts['course_id']) {
            return '';
        }

        // Get course settings
        $course_settings = get_post_meta($atts['course_id'], '_sfwd-courses', true);

        // Get the custom button URL
        if (isset($course_settings['sfwd-courses_custom_button_url']) && $course_settings['sfwd-courses_custom_button_url'] !== '') {
            $button_url = $course_settings['sfwd-courses_custom_button_url'];
        } else {
            $button_url = '';
        }

        if (empty($button_url)) {
            return '';
        }

        // Extract product ID and create checkout URL
        $product_id = $this->extract_product_id_from_url($button_url);
        if (!$product_id) {
            return '';
        }

        // Create direct checkout URL
        $checkout_url = add_query_arg(
            array(
                'add-to-cart' => $product_id,
                'quantity' => 1,
            ),
            wc_get_checkout_url()
        );

        // Get product info
        $product = wc_get_product($product_id);
        if (!$product) {
            return '';
        }

        // Build CSS classes based on style attribute
        $button_classes = array('ld-buy-now-button');
        $wrapper_classes = array('ld-buy-now-wrapper');

        if (!empty($atts['class'])) {
            $button_classes[] = $atts['class'];
        }

        switch ($atts['style']) {
            case 'plain':
                $button_classes[] = 'plain-style';
                break;
            case 'minimal':
                $button_classes[] = 'minimal-style';
                break;
            default:
                $button_classes[] = 'default-style';
        }

        // Check if user is already enrolled
        $user_id = get_current_user_id();
        $course_id = (int) $atts['course_id'];

        if (is_user_logged_in() && function_exists('sfwd_lms_has_access')) {
            if (sfwd_lms_has_access($course_id, $user_id)) {
                return '<h4 class="text-center">You are already enrolled in this course.</h4>'; // User is enrolled — hide the buy button
            }
        }

        // Start building output
        $output = '<div class="' . esc_attr(implode(' ', $wrapper_classes)) . '">';

        // Add price if enabled
        if ($atts['show_price'] === 'yes') {
            $output .= '<div class="ld-buy-now-price">' . wc_price($product->get_price()) . '</div>';
        }

        // Add button
        $output .= '<button type="button" id="instant-buy-now" class="' . esc_attr(implode(' ', $button_classes)) . '">' . esc_html($atts['button_text']) . '</button>';
        $output .= '<input type="hidden" name="product_id" id="product_id" value="' . esc_attr($product_id) . '">';

        // Add modal HTML
        $output .= $this->get_modal_html();

        $output .= '</div>';

        return $output;
    }

    /**
     * Get modal HTML
     */
    private function get_modal_html() {
        ob_start();
        ?>
        <div id="buy-now-modal" class="ldbnb-modal">
            <div class="ldbnb-modal-content">
                <div class="ldbnb-modal-header">
                    <h3><?php _e('Checkout Options', 'learndash-buy-now'); ?></h3>
                    <span class="ldbnb-close">&times;</span>
                </div>
                <div class="ldbnb-modal-body">
                    <p><?php _e('Choose how you would like to complete your purchase', 'learndash-buy-now'); ?></p>
                    <div class="ldbnb-buttons">
                        <button id="btn-instant-checkout" class="ldbnb-button ldbnb-primary">
                            <span class="ldbnb-icon">💳</span> <?php _e('Instant Checkout', 'learndash-buy-now'); ?>
                        </button>
                        <button id="btn-regular-checkout" class="ldbnb-button ldbnb-secondary">
                            <span class="ldbnb-icon">🛒</span> <?php _e('Go to Checkout', 'learndash-buy-now'); ?>
                        </button>
                    </div>
                </div>
                <div class="ldbnb-modal-footer">
                    <button id="btn-cancel-checkout" class="ldbnb-button ldbnb-ghost">
                        <?php _e('Cancel', 'learndash-buy-now'); ?>
                    </button>
                </div>
            </div>
        </div>

        <!-- Error Modal -->
        <div id="payment-error-modal" class="ldbnb-error-modal">
            <div class="ldbnb-error-content">
                <div class="ldbnb-error-header">
                    <h3><?php _e('Payment Failed', 'learndash-buy-now'); ?></h3>
                    <span class="ldbnb-close error-close">&times;</span>
                </div>
                <div class="ldbnb-error-body">
                    <p id="error-message"><?php _e('We’re unable to process your payment.Please update your card details or add a new card on the checkout page to complete your purchase.', 'learndash-buy-now'); ?></p>
                </div>
                <div class="ldbnb-error-footer">
                    <button id="error-close-btn" class="ldbnb-error-close">
                        <?php _e('Close', 'learndash-buy-now'); ?>
                    </button>
                    <button id="go-to-checkout-btn" class="ldbnb-checkout-button">
                        <?php _e('Go to Checkout', 'learndash-buy-now'); ?>
                    </button>
                </div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    /**
     * Extract product ID from WooCommerce URL
     */
    public function extract_product_id_from_url($url) {
        // Parse the URL
        $parsed_url = parse_url($url);

        if (!isset($parsed_url['path'])) {
            return false;
        }

        // Get the path and remove trailing slash
        $path = rtrim($parsed_url['path'], '/');

        // Try to get product ID from query string if it exists
        if (isset($parsed_url['query'])) {
            parse_str($parsed_url['query'], $query_vars);
            if (isset($query_vars['product_id'])) {
                return $query_vars['product_id'];
            }
            if (isset($query_vars['add-to-cart'])) {
                return $query_vars['add-to-cart'];
            }
        }

        // Try to get product ID from the slug
        $slug = basename($path);

        // First try to get product by slug
        $product = get_page_by_path($slug, OBJECT, 'product');
        if ($product) {
            return $product->ID;
        }

        // If slug is numeric, it might be the ID
        if (is_numeric($slug)) {
            return $slug;
        }

        // If we still don't have an ID, try to find the product by its slug
        $products = get_posts(array(
            'post_type' => 'product',
            'name' => $slug,
            'posts_per_page' => 1,
            'post_status' => 'publish'
        ));

        if (!empty($products)) {
            return $products[0]->ID;
        }

        return false;
    }

    /**
     * Process instant buy now
     */
    public function process_instant_buy_now() {
        try {
            if (!is_user_logged_in()) {
                wp_send_json(['success' => false, 'message' => 'Please log in first.']);
            }

            if (!isset($_POST['product_id']) || empty($_POST['product_id'])) {
                wp_send_json(['success' => false, 'message' => 'Invalid Product ID.']);
            }

            $user_id = get_current_user_id();
            $product_id = intval($_POST['product_id']);
            $product = wc_get_product($product_id);

            if (!$product) {
                wp_send_json(['success' => false, 'message' => 'Product not found.']);
            }

            $checkout_url = add_query_arg(
                array(
                    'add-to-cart' => $product_id,
                    'quantity' => 1,
                ),
                wc_get_checkout_url()
            );

            // Get Stripe Customer ID
            $stripe_customer_id = get_user_meta($user_id, '_stripe_customer_id', true);

            if (!$stripe_customer_id) {
                wp_send_json(['success' => true, 'redirect' => $checkout_url]);
            }

            // Create a new WooCommerce order
            $order = wc_create_order();
            $order->set_customer_id($user_id);
            $order->add_product($product, 1);
            $order->calculate_totals();

            // Get saved payment tokens from WooCommerce
            $payment_methods = WC_Payment_Tokens::get_customer_tokens($user_id);

            if (empty($payment_methods)) {
                wp_send_json(['success' => false, 'message' => 'No saved payment methods available.']);
            }

            // Find the first valid Stripe payment method
            $payment_method_id = null;
            foreach ($payment_methods as $method) {
                if ($method->get_gateway_id() === 'fkwcs_stripe') { // Ensures we use Stripe
                    $payment_method_id = $method->get_token();
                    break;
                }
            }

            if (!$payment_method_id) {
                wp_send_json(['success' => false, 'message' => 'No valid Stripe payment method found.']);
            }

            // Get Stripe API key
            $test_secret_key = get_option('fkwcs_test_secret_key');
            $live_secret_key = get_option('fkwcs_secret_key');
            $stripe_secret = isset($live_secret_key) ? get_option('fkwcs_secret_key') : null;

            if (!$stripe_secret) {
                wp_send_json(['success' => false, 'message' => 'Stripe secret key is missing in FunnelKit settings.']);
            }

            // Process payment with Stripe
            $stripe = new \Stripe\StripeClient($stripe_secret);

            $payment_intent = $stripe->paymentIntents->create([
                'amount' => $order->get_total() * 100, // Convert to cents
                'currency' => strtolower(get_woocommerce_currency()),
                'customer' => $stripe_customer_id,
                'payment_method' => $payment_method_id,
                'confirm' => true,
                'off_session' => true,
            ]);

            if ($payment_intent->status === 'succeeded') {
                $order->payment_complete($payment_intent->id);
                $order->update_status('completed', 'Order paid successfully via Buy Now button.');
                wp_send_json(['success' => true, 'message' => 'Payment successful!', 'redirect' => $order->get_checkout_order_received_url()]);
            } else {
                wp_send_json([
                    'success' => false,
                    'message' => 'We’re unable to process your payment.Please update your card details or add a new card on the checkout page to complete your purchase.',
                    'checkout_url' => $checkout_url
                ]);
            }
        } catch (Exception $e) {
            error_log('Buy Now Error: ' . $e->getMessage());
            wp_send_json([
                'success' => false,
                'message' => 'We’re unable to process your payment.Please update your card details or add a new card on the checkout page to complete your purchase.',
                'error_details' => $e->getMessage(),
                'checkout_url' => $checkout_url
            ]);
        }
    }
}

// Initialize the plugin
function learndash_buy_now_button_init() {
    // Check if WooCommerce and LearnDash are active
    if (class_exists('WooCommerce') && defined('LEARNDASH_VERSION')) {
        new LearnDash_Buy_Now_Button();
    }
}
add_action('plugins_loaded', 'learndash_buy_now_button_init');
