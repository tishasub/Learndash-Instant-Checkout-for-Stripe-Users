"use client"

import  from "../assets/js/scripts"

export default function SyntheticV0PageForDeployment() {
  return < />
}