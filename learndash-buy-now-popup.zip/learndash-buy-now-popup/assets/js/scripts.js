/**
 * LearnDash Buy Now Button Scripts
 */
;(($) => {
  $(document).ready(() => {
    // Modal elements
    const $modal = $("#buy-now-modal")
    const $errorModal = $("#payment-error-modal")
    const $closeBtn = $(".ldbnb-close")
    const $errorCloseBtn = $(".error-close, #error-close-btn")
    const $cancelBtn = $("#btn-cancel-checkout")
    const $instantBtn = $("#btn-instant-checkout")
    const $regularBtn = $("#btn-regular-checkout")
    const $buyNowBtn = $("#instant-buy-now")
    const $goToCheckoutBtn = $("#go-to-checkout-btn")
    const $errorMessage = $("#error-message")

    let checkoutUrl = ""

    // Show modal when Buy Now button is clicked
    $buyNowBtn.on("click", () => {
      $modal.fadeIn(300)
    })

    // Close modal functions
    function closeModal() {
      $modal.fadeOut(200)
    }

    function closeErrorModal() {
      $errorModal.fadeOut(200)
    }

    $closeBtn.on("click", closeModal)
    $errorCloseBtn.on("click", closeErrorModal)
    $cancelBtn.on("click", closeModal)

    // Close modals when clicking outside
    $(window).on("click", (event) => {
      if ($(event.target).is($modal)) {
        closeModal()
      }
      if ($(event.target).is($errorModal)) {
        closeErrorModal()
      }
    })

    // Handle Go to Checkout button in error modal
    $goToCheckoutBtn.on("click", () => {
      if (checkoutUrl) {
        window.location.href = checkoutUrl
      } else {
        closeErrorModal()
      }
    })

    // Handle Instant Checkout
    $instantBtn.on("click", () => {
      const productId = $("#product_id").val()

      if (!productId) {
        alert("Product ID is missing!")
        return
      }

      // Show loading state
      const originalText = $instantBtn.text()
      $instantBtn.html('<span class="ldbnb-loading"></span> Processing...')
      $instantBtn.prop("disabled", true)

      // Process AJAX request
      $.ajax({
        type: "POST",
        url: ajaxurl,
        data: {
          action: "instant_buy_now",
          product_id: productId,
        },
        success: (response) => {
          if (response.success) {
            if (response.message) {
              // Optional: Show success message before redirect
              alert(response.message)
            }
            window.location.href = response.redirect
          } else {
            // Store checkout URL for the error modal
            if (response.checkout_url) {
              checkoutUrl = response.checkout_url
            }

            // Show error message in the modal
            if (response.message) {
              $errorMessage.text(response.message)
            }

            // Close checkout modal and show error modal
            closeModal()
            $errorModal.fadeIn(300)

            // Reset button state
            $instantBtn.html(originalText)
            $instantBtn.prop("disabled", false)
          }
        },
        error: () => {
          $errorMessage.text("A server error occurred. Please try again.")
          closeModal()
          $errorModal.fadeIn(300)
          $instantBtn.html(originalText)
          $instantBtn.prop("disabled", false)
        },
      })
    })

    // Handle Regular Checkout
    $regularBtn.on("click", () => {
      const productId = $("#product_id").val()

      if (!productId) {
        alert("Product ID is missing!")
        return
      }

      // Redirect to regular checkout
      window.location.href = wc_checkout_url + "?add-to-cart=" + productId + "&quantity=1"
    })
  })
})(jQuery)
